package flight;

/**
 * Created by peter on 2/3/16.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Peter".hashCode());
        System.out.println(new Token("Peter",true));
    }
}
