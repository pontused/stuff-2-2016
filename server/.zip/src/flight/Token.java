package flight;


import javax.annotation.Resource;
import javax.jws.soap.SOAPBinding;
import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

/**
 * Created by peter on 2/3/16.
 */

//@SOAPBinding(style = SOAPBinding.Style.RPC)
public class Token implements Serializable {

    private String name;
    private Integer token;

    public Token(){}
    public Token(String name,boolean success){
        this.name = name;
        if (success){
            this.token = genToken(name);
        }else token = 123;
    }

    private int genToken(String name){
        long time = System.currentTimeMillis();
        return (name + time).hashCode();

    }
    public Integer getToken(){
        return token;
    }
    public String toString(){
        return "faseh "+ token;//token+"";
    }
}
