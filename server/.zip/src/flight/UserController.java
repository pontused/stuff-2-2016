package flight;

import java.util.ArrayList;
import java.util.TreeMap;

/**
 * Created by peter on 2/3/16.
 */
public class UserController {

    private static TreeMap<String,User> userDB;
    private static TreeMap<String,Token> tokenDB;

    public UserController(){
        userDB = new TreeMap<String,User>();
        tokenDB = new TreeMap<String, Token>();
        userDB = genUsers();
    }

    private TreeMap<String,User> genUsers(){
        TreeMap<String,User> list = new TreeMap<String,User>();

        list.put("peter",new User("peter","peter"));
        return list;
    }
    public Token authenticate(String user, String pass){
        Token token = new Token(user,true);
        tokenDB.put(user,token);
        return token;
        /*
        if (users.containsKey(user)){
            if (users.get(user).getPassword().equals(pass)){
                tokenDB.put(user,token);
                return new Token(user,true);
            }
        }
        return new Token(user,false);
        */
    }


}
