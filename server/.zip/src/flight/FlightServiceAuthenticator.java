package flight;

import order.OrderBean;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import java.util.List;
import java.util.Map;

/**
 * Created by peter on 1/31/16.
 */

//@WebService()

@WebService(endpointInterface = "flight.Authenticator", serviceName = "Authenticator", portName = "AuthenticatorPort", targetNamespace = "http://www.authenticator.com")
public class FlightServiceAuthenticator implements Authenticator {

    private UserController controller = new UserController();

    @Resource
    WebServiceContext wsctx;

    @WebMethod(operationName = "authenticate")
    //public Token authenticate(@WebParam(name = "name") String name, @WebParam(name = "pass") String pass) {
    public Token authenticate(String name, String pass) {

        System.out.println(name+ " " +pass);
        MessageContext mctx = wsctx.getMessageContext();

        Token token = controller.authenticate(name, pass);
        System.out.println("test "+token);
        return token;


    }

}


/*
 //get detail from request headers
        Map http_headers = (Map) mctx.get(MessageContext.HTTP_REQUEST_HEADERS);
        List userList = (List) http_headers.get("Username");
        List passList = (List) http_headers.get("Password");

        String username = "";
        String password = "";

        if (userList != null) {
            //get username
            username = userList.get(0).toString();
        }

        if (passList != null) {
            //get password
            password = passList.get(0).toString();
        }
        return true;
    }
 */