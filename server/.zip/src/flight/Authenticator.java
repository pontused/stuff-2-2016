package flight;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

/**
 * Created by peter on 2/3/16.
 */
@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC)
public interface Authenticator{

    @WebMethod
    Token authenticate(String username,String password);

}
