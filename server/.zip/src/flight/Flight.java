package flight;

/**
 * Created by peter on 2/1/16.
 */
public class Flight {

    private final String airline;
    private final String departureCity;
    private final String destinationCity;
    private float price;

    public Flight(String airline, String departureCity, String destinationCity, float price) {
        this.airline = airline;
        this.departureCity = departureCity;
        this.destinationCity = destinationCity;
        this.price = price;

    }


    public String getAirline() {
        return airline;
    }

    public String getDepartureCity() {
        return departureCity;
    }

    public String getDestinationCity() {
        return destinationCity;
    }
    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
