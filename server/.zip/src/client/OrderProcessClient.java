package client;


import com.sun.xml.xsom.impl.scd.TokenMgrError;
import flight.Authenticator;
import flight.FlightServiceAuthenticator;
import flight.Token;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.URL;

/**
 * Created by peter on 1/31/16.
 */
public class OrderProcessClient {




    public static void main(String[] args) {

        new OrderProcessClient();
        //1st argument service URI, refer to wsdl document above
        //2nd argument is service name, refer to wsdl document above

    }

    public OrderProcessClient(){
        login();
    }
    private void login(){
        String wsdl = "http://localhost:8080/server_war_exploded/Authenticator?wsdl";
        try{
            URL url = new URL(wsdl);
            QName qname = new QName("http://www.authenticator.com", "Authenticator");

            Service service = Service.create(url, qname);

            Authenticator hello = service.getPort(Authenticator.class);
            Token token = hello.authenticate("peter","peter");


            if (token.getToken() != null){

                System.out.println("We're in!");

            }
            System.out.println(token);

        }catch (Exception e){
            System.out.println(e);
        }
    }

}
