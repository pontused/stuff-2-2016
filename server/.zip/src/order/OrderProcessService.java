package order;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService(serviceName = "OrderProcess", portName = "OrderProcessPort", targetNamespace = "http://www.orderprocess.com")

@SOAPBinding(style = SOAPBinding.Style.DOCUMENT, use= SOAPBinding.Use.LITERAL, parameterStyle = SOAPBinding.ParameterStyle.WRAPPED)


public class OrderProcessService {
    @WebMethod
    public OrderBean processOrder(OrderBean orderBean) {


        System.out.println("processOrder called for customer" + orderBean.getCustomer().getCustomerId());
        if (orderBean.getOrderItems() != null) {
            System.out.println("Number of items is " + orderBean.getOrderItems().length);
        }
        orderBean.setOrderId("A2234");
        return orderBean;
    }
}