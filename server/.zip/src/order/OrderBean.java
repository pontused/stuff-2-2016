package order;

import javax.annotation.ManagedBean;

/**
 * Created by peter on 1/31/16.
 */

@ManagedBean
public class OrderBean {
    private Customer customer;
    private Address shippingAddress;
    private OrderItem[] orderItems;
    private String orderId;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Address getShippingAddress() {
        return shippingAddress;
    }
    public OrderItem[] getOrderItems(){
        return orderItems;
    }
}