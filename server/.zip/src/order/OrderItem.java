package order;

import javax.annotation.ManagedBean;

/**
 * Created by peter on 1/31/16.
 */

@ManagedBean
public class OrderItem {
}
