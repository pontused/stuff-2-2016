package order;

import javax.annotation.ManagedBean;

/**
 * Created by peter on 1/31/16.
 */
@ManagedBean
public class Customer {

    private int customerId;

    public int getCustomerId(){
        return customerId;
    }
}
